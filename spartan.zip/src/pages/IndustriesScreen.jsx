import React, { useEffect, useState } from "react";
import Header from "../component/Header";
import Footer from "../component/Footer";
import "../assets/css/industryScreen.css";
import { useDispatch, useSelector } from "react-redux";

// --- PLACEHOLDER IMAGE PATHS (Replace these with your actual figma exports) ---
import envIcon1 from "../assets/images/industryScreen/env-icon1.png";
import envIcon2 from "../assets/images/industryScreen/env-icon2.png";
import envIcon3 from "../assets/images/industryScreen/env-icon3.png";
import envIcon4 from "../assets/images/industryScreen/env-icon4.png";
import startBullet from "../assets/images/approachScreen/startBullet.png";

import industryImg1 from "../assets/images/industryScreen/construction.jpg";
import industryImg2 from "../assets/images/industryScreen/defense.jpg";
import industryImg3 from "../assets/images/industryScreen/aviation.jpg";
import industryImg4 from "../assets/images/industryScreen/engineering.jpg";
import industryImg5 from "../assets/images/industryScreen/manufacturing.jpg";
import { Link } from "react-router-dom";
import { industryScreenData } from "../redux/slices/secondSlice";
import SEO from "../component/SEO";

const IMAGE_URL = import.meta.env.VITE_IMAGE_URL;

const IndustriesScreen = () => {
  const dispatch = useDispatch();
  const { industryData, loading } = useSelector((state) => state.second);

  const [activeFaqId, setActiveFaqId] = useState();

  const toggleFaq = (id) => {
    setActiveFaqId(activeFaqId === id ? null : id);
  };

  useEffect(() => {
    dispatch(industryScreenData());
  }, [dispatch]);

  const environments = [envIcon1, envIcon2, envIcon3, envIcon4];

  const sectors = [
    {
      title: "Construction & Federal Infrastructure",
      desc: "General contractors, design-build firms and AEC teams delivering federal, MILCON and critical infrastructure projects.",
      points: [
        "CUI protection for site plans, BIM/CAD and project schedules",
        "Subcontractor and trade partner flowdown management",
        "Field device and mobile workforce hardening (tablets, BYOD)",
      ],
      image: industryImg1,
      imageRight: true, // Image on the right side
    },
    {
      title: "Defense & Aerospace",
      desc: "Prime and subcontractor support across DoD weapon systems and platforms.",
      points: [
        "CUI segmentation across engineering data",
        "ITAR-aligned access controls",
        "Subcontractor flowdown management",
      ],
      image: industryImg2,
      imageRight: false, // Image on the left side (Alternating)
    },
    {
      title: "Aviation & Logistics",
      desc: "Supply chain and logistics partners moving CUI across the DIB.",
      points: [
        "Logistics data protection",
        "Multi-site compliance posture",
        "Vendor risk management",
      ],
      image: industryImg3,
      imageRight: true,
    },
    {
      title: "Engineering & R&D",
      desc: "Research Organization handling sensitive controlled technical data.",
      points: [
        "Research enclave architecture",
        "Lab and BYOD device control",
        "Export-controlled data handling",
      ],
      image: industryImg4,
      imageRight: false,
    },
    {
      title: "Advanced Manufacturing",
      desc: "Precision manufacturers producing components for DoD and federal supply chains.",
      points: [
        "OT/IT segmentation for shop floors",
        "CAD and CAM data protection",
        "Supplier portal hardening",
      ],
      image: industryImg5,
      imageRight: true,
    },
  ];

  console.log("industryData___", industryData?.industry_faq_content)

  return (
    <>
      <SEO
        title="CMMC 2.0 Compliance by Industry | Spartan Cyber Security"
        description="CMMC 2.0 compliance by industry — sector-specific guidance for manufacturing, aerospace, and defense supply chain contractors pursuing certification."
        url="https://spartan-cs.com/industries"
      />
      <Header />
      <main className="industries-main">
        {/* 1. HERO SECTION */}
        <div className="blog-hero-fullwidth">
          <div className="custom-container">
            <div className="blog-hero-content blog-hero-content1">
              <div className="blog-breadcrumb">
                <Link to="/" style={{ textDecoration: "none" }}><span style={{ color: "white" }}>Home</span></Link> <span className="separator">|</span>{" "}
                <span>Industries</span>
              </div>
              <h1 className="blog-hero-title">
                {industryData?.industry_sec_heading}
              </h1>
              <p className="blog-hero-subtitle">
                {industryData?.industry_sec_paragraph}
              </p>
            </div>
          </div>
        </div>

        {/* 2. ENVIRONMENTS SECTION */}
        <section className="environments-section">
          <div className="custom-container">
            <div className="section-tag-wrapper justify-content-start">
              <span className="section-mini-tag">
                <span className="fallback-red-dot"></span>WHO WE SERVE
              </span>
            </div>
            <h2 className="section-main-heading mb-5">
              {industryData?.industry_sec_serve_heading}
            </h2>

            <div className="row g-4">
              {/* {environments.map((env, idx) => ( */}
              {industryData?.industry_sec_content?.map((env, idx) => (
                <div className="col-xl-3 col-md-6" key={idx}>
                  <div className="env-card">
                    <div className="env-icon-box">
                      <img
                        src={environments[idx]}
                        alt=""
                        className="env-figma-icon"
                        onError={(e) => {
                          e.target.style.display = "none";
                        }}
                      />
                      {/* <span className="fallback-red-dot"></span> */}
                    </div>
                    <h5 className="env-title">{env.title}</h5>
                    <p className="env-desc">{env.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 3. SECTOR DETAILS (ALTERNATING LAYOUTS) */}
        <section className="sectors-detail-section">
          <div className="custom-container">
            <div className="section-tag-wrapper">
              <span className="section-mini-tag">
                <span className="fallback-red-dot"></span>VERTICALS
              </span>
            </div>
            <h2 className="section-main-heading text-center mb-5">
              {industryData?.industry_sec_vertical_content}
            </h2>

            <div className="sectors-stack">
              {/* {sectors.map((sec, idx) => ( */}
              {industryData?.industry_sec_card_content?.map((sec, idx) => (
                <div
                  className={`row sector-row align-items-stretch g-0 ${sec.imageRight === "1" ? "" : "flex-row-reverse"
                    }`}
                  key={idx}
                >
                  {/* Text Column */}
                  <div className="col-lg-6">
                    <div className="sector-text-block">
                      <h3 className="sector-title">{sec.title}</h3>
                      <p className="sector-desc">{sec.description}</p>
                      <ul className="sector-points-list">
                        {sec.points.map((pt, pIdx) => (
                          <li key={pIdx}>
                            <span className="red-arrow">
                              <img src={startBullet} alt="" />
                            </span>
                            {pt}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Image Column */}
                  <div className="col-lg-6">
                    <div className="sector-image-block">
                      <img
                        src={sec?.image}
                        alt={sec?.title}
                        className="sector-display-img"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </section>

        {/* ===================faq section=========== */}

        <section className="resource-faq-section" style={{marginTop: "60px"}}>
          <div className="section-inner-content faq-layout-grid">
            {/* Left Column Sticky Header Block */}
            <div className="faq-left-header-panel">
              <div className="faq-mini-badge">
                <span className="badge-dot-indicator" />
                <span className="badge-label-text">FAQ</span>
              </div>
              <h2 className="faq-panel-title">
                You Have Questions.
                <br />
                We Have Answers.
              </h2>
              <Link
                to=""
                className="btn-red-action"
                style={{ marginTop: "15px" }}
              >
                Find More Answers <i className="fas fa-arrow-right"></i>
              </Link>
            </div>

            {/* Right Column Interactive Accordion Stack */}
            <div className="faq-right-accordion-panel">
              {industryData?.industry_faq_content?.map((item, index) => {
                const isOpen = activeFaqId === item.id;
                return (
                  <div
                    key={item?.id}
                    className={`faq-accordion-row ${isOpen ? "is-expanded" : ""}`}
                    onClick={() => toggleFaq(item?.id)}
                  >
                    <div className="faq-row-trigger-line">
                      <h3 className="faq-question-text">{item?.question}</h3>
                      <div
                        className={`faq-toggle-circle-indicator ${isOpen ? "active-minus" : "inactive-plus"
                          }`}
                      >
                        {isOpen ? (
                          /* Minus SVG Icon */
                          <svg
                            width="12"
                            height="2"
                            viewBox="0 0 12 2"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M1 1H11"
                              stroke="#FFFFFF"
                              strokeWidth="2"
                              strokeLinecap="round"
                            />
                          </svg>
                        ) : (
                          /* Plus SVG Icon */
                          <svg
                            width="12"
                            height="12"
                            viewBox="0 0 12 12"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M6 1V11M1 6H11"
                              stroke="#27272A"
                              strokeWidth="2"
                              strokeLinecap="round"
                            />
                          </svg>
                        )}
                      </div>
                    </div>

                    {/* Smooth height container breakdown space */}
                    <div className="faq-row-collapsible-content">
                      <div className="faq-answer-inner-wrapper">
                        <p className="faq-answer-paragraph">{item?.answer}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* 4. CALL TO ACTION SECTION */}
        <section className="industries-cta-section">
          <div className="custom-container">
            <div className="industries-cta-banner">
              <span className="section-mini-tag dark-theme-tag mb-3">
                <span className="fallback-red-dot"></span>GET STARTED
              </span>
              <h2 className="cta-banner-title">
                {industryData?.industry_sec_started_heading}
              </h2>
              <p className="cta-banner-desc">
                {industryData?.industry_sec_started_paragraph}
              </p>
              <div className="cta-buttons-group">
                <Link
                  to="/contact-us"
                  className="cta-btn-white"
                  style={{ textDecoration: "none" }}
                >
                  Schedule Consultation <span>→</span>
                </Link>
                <Link
                  to="/compliance-systems"
                  className="cta-btn-outline"
                  style={{ textDecoration: "none" }}
                >
                  Explore Compliance
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default IndustriesScreen;
